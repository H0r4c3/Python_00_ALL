from .base_page import BasePage
class LoginPage(BasePage):
    pass
