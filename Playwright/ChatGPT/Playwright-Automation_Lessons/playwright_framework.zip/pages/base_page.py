class BasePage:
    pass
